import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:saudi_vat_scanner/l10n/generated/app_localizations.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await MobileAds.instance.initialize();
  runApp(const SaudiVatScannerApp());
}

class SaudiVatScannerApp extends StatefulWidget {
  const SaudiVatScannerApp({super.key});

  @override
  State<SaudiVatScannerApp> createState() => _SaudiVatScannerAppState();
}

class _SaudiVatScannerAppState extends State<SaudiVatScannerApp> {
  static const String _languageKey = 'selected_language_code';
  Locale? _locale;

  @override
  void initState() {
    super.initState();
    _loadSavedLanguage();
  }

  Future<void> _loadSavedLanguage() async {
    final prefs = await SharedPreferences.getInstance();
    final code = prefs.getString(_languageKey);
    if (!mounted || code == null) return;
    setState(() => _locale = Locale(code));
  }

  Future<void> _toggleLanguage() async {
    final currentCode = _locale?.languageCode ?? 'en';
    final nextCode = currentCode == 'ar' ? 'en' : 'ar';
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_languageKey, nextCode);
    if (!mounted) return;
    setState(() => _locale = Locale(nextCode));
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      onGenerateTitle: (context) => AppLocalizations.of(context)!.appTitle,
      locale: _locale,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF006C67)),
        useMaterial3: true,
      ),
      localizationsDelegates: const [
        AppLocalizations.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [
        Locale('en'),
        Locale('ar'),
      ],
      home: HomeScreen(onToggleLanguage: _toggleLanguage),
      debugShowCheckedModeBanner: false,
    );
  }
}

class ZatcaQrResult {
  const ZatcaQrResult({required this.tags, this.error});

  final Map<int, String> tags;
  final String? error;

  bool get isValid => error == null && tags.isNotEmpty && _hasMinimumRequiredTags;

  bool get _hasMinimumRequiredTags {
    for (final tag in [1, 2, 3, 4, 5]) {
      if (!tags.containsKey(tag) || tags[tag]!.trim().isEmpty) return false;
    }
    return true;
  }

  bool get isPhase2 => tags.containsKey(6) || tags.containsKey(7) || tags.containsKey(8) || tags.containsKey(9);

  String get sellerName => tags[1] ?? '';
  String get vatNumber => tags[2] ?? '';
  String get timestamp => tags[3] ?? '';
  String get invoiceTotal => tags[4] ?? '';
  String get vatTotal => tags[5] ?? '';
}

class ZatcaQrDecoder {
  static ZatcaQrResult decode(String base64String) {
    final Map<int, String> decodedData = {};

    try {
      final normalized = base64.normalize(base64String.trim());
      final Uint8List decodedBytes = base64Decode(normalized);

      int index = 0;
      while (index < decodedBytes.length) {
        if (index + 2 > decodedBytes.length) {
          return const ZatcaQrResult(tags: {}, error: 'Malformed TLV data');
        }

        final int tag = decodedBytes[index++];
        final int length = decodedBytes[index++];

        if (length < 0 || index + length > decodedBytes.length) {
          return const ZatcaQrResult(tags: {}, error: 'Invalid TLV length');
        }

        final value = decodedBytes.sublist(index, index + length);
        index += length;

        if (tag >= 1 && tag <= 5) {
          decodedData[tag] = utf8.decode(value, allowMalformed: true);
        } else {
          decodedData[tag] = base64Encode(value);
        }
      }

      final result = ZatcaQrResult(tags: decodedData);
      if (!result._hasMinimumRequiredTags) {
        return const ZatcaQrResult(tags: {}, error: 'Missing required ZATCA tags');
      }
      return result;
    } catch (_) {
      return const ZatcaQrResult(tags: {}, error: 'Invalid Base64 or TLV data');
    }
  }
}

class ScanHistoryItem {
  ScanHistoryItem({
    required this.qrData,
    required this.scannedAt,
    required this.sellerName,
    required this.invoiceTotal,
    required this.vatTotal,
    required this.isPhase2,
  });

  final String qrData;
  final DateTime scannedAt;
  final String sellerName;
  final String invoiceTotal;
  final String vatTotal;
  final bool isPhase2;

  Map<String, dynamic> toJson() => {
        'qrData': qrData,
        'scannedAt': scannedAt.toIso8601String(),
        'sellerName': sellerName,
        'invoiceTotal': invoiceTotal,
        'vatTotal': vatTotal,
        'isPhase2': isPhase2,
      };

  static ScanHistoryItem fromJson(Map<String, dynamic> json) => ScanHistoryItem(
        qrData: json['qrData'] as String? ?? '',
        scannedAt: DateTime.tryParse(json['scannedAt'] as String? ?? '') ?? DateTime.now(),
        sellerName: json['sellerName'] as String? ?? '',
        invoiceTotal: json['invoiceTotal'] as String? ?? '',
        vatTotal: json['vatTotal'] as String? ?? '',
        isPhase2: json['isPhase2'] as bool? ?? false,
      );
}

class ScanHistoryStore {
  static const String _historyKey = 'scan_history_v1';
  static const int _maxHistoryItems = 50;

  static Future<List<ScanHistoryItem>> load() async {
    final prefs = await SharedPreferences.getInstance();
    final items = prefs.getStringList(_historyKey) ?? [];
    return items
        .map((raw) {
          try {
            return ScanHistoryItem.fromJson(jsonDecode(raw) as Map<String, dynamic>);
          } catch (_) {
            return null;
          }
        })
        .whereType<ScanHistoryItem>()
        .toList();
  }

  static Future<void> add(ScanHistoryItem item) async {
    final prefs = await SharedPreferences.getInstance();
    final items = await load();
    items.removeWhere((old) => old.qrData == item.qrData);
    items.insert(0, item);
    final limited = items.take(_maxHistoryItems).map((e) => jsonEncode(e.toJson())).toList();
    await prefs.setStringList(_historyKey, limited);
  }

  static Future<void> remove(String qrData) async {
    final prefs = await SharedPreferences.getInstance();
    final items = await load();
    items.removeWhere((old) => old.qrData == qrData);
    await prefs.setStringList(_historyKey, items.map((e) => jsonEncode(e.toJson())).toList());
  }

  static Future<void> clear() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_historyKey);
  }
}

class AdMobIds {
  // TODO: Replace these Google test ad unit IDs before Play Store/App Store release.
  static String get bannerAdUnitId {
    if (Platform.isAndroid) return 'ca-app-pub-3940256099942544/6300978111';
    if (Platform.isIOS) return 'ca-app-pub-3940256099942544/2934735716';
    return 'unused';
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key, required this.onToggleLanguage});

  final Future<void> Function() onToggleLanguage;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  BannerAd? _bannerAd;
  bool _isAdLoaded = false;

  @override
  void initState() {
    super.initState();
    _loadBannerAd();
  }

  void _loadBannerAd() {
    if (!Platform.isAndroid && !Platform.isIOS) return;
    _bannerAd = BannerAd(
      size: AdSize.banner,
      adUnitId: AdMobIds.bannerAdUnitId,
      listener: BannerAdListener(
        onAdLoaded: (_) {
          if (mounted) setState(() => _isAdLoaded = true);
        },
        onAdFailedToLoad: (ad, error) {
          debugPrint('Failed to load banner ad: ${error.message}');
          ad.dispose();
        },
      ),
      request: const AdRequest(),
    )..load();
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.appTitle),
        centerTitle: true,
        actions: [
          TextButton(
            onPressed: widget.onToggleLanguage,
            child: Text(l10n.languageButton),
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Icon(
                Icons.qr_code_scanner_rounded,
                size: 130,
                color: Theme.of(context).colorScheme.primary,
              ),
              const SizedBox(height: 24),
              Text(
                l10n.supportText,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 8),
              Text(
                l10n.phaseDisclaimer,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 13, color: Theme.of(context).colorScheme.onSurfaceVariant),
              ),
              const SizedBox(height: 40),
              FilledButton.icon(
                icon: const Icon(Icons.camera_alt),
                label: Text(l10n.scanButton),
                style: FilledButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                onPressed: () async {
                  final result = await Navigator.push<bool>(
                    context,
                    MaterialPageRoute(builder: (context) => const ScannerScreen()),
                  );
                  if (result == true && mounted) setState(() {});
                },
              ),
              const SizedBox(height: 12),
              OutlinedButton.icon(
                icon: const Icon(Icons.history),
                label: Text(l10n.historyButton),
                style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => const HistoryScreen()),
                  );
                },
              ),
              const SizedBox(height: 24),
              Text(
                l10n.cameraPermissionNote,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: Theme.of(context).colorScheme.onSurfaceVariant),
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: _isAdLoaded && _bannerAd != null
          ? SafeArea(
              child: SizedBox(
                width: _bannerAd!.size.width.toDouble(),
                height: _bannerAd!.size.height.toDouble(),
                child: AdWidget(ad: _bannerAd!),
              ),
            )
          : const SizedBox.shrink(),
    );
  }
}

class ScannerScreen extends StatefulWidget {
  const ScannerScreen({super.key});

  @override
  State<ScannerScreen> createState() => _ScannerScreenState();
}

class _ScannerScreenState extends State<ScannerScreen> {
  final MobileScannerController _controller = MobileScannerController();
  bool _isNavigating = false;

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.scanScreenTitle),
        actions: [
          IconButton(
            tooltip: 'Flash',
            onPressed: () => _controller.toggleTorch(),
            icon: const Icon(Icons.flash_on),
          ),
        ],
      ),
      body: Stack(
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: (capture) async {
              if (_isNavigating) return;
              final barcodes = capture.barcodes;
              if (barcodes.isEmpty || barcodes.first.rawValue == null) return;

              setState(() => _isNavigating = true);
              await _controller.stop();

              if (!mounted) return;
              final saved = await Navigator.push<bool>(
                context,
                MaterialPageRoute(
                  builder: (context) => ResultScreen(qrData: barcodes.first.rawValue!),
                ),
              );
              if (!mounted) return;
              Navigator.pop(context, saved == true);
            },
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              width: double.infinity,
              margin: const EdgeInsets.all(16),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.55),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Text(
                l10n.sampleNote,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class ResultScreen extends StatefulWidget {
  const ResultScreen({super.key, required this.qrData});

  final String qrData;

  @override
  State<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends State<ResultScreen> {
  late final ZatcaQrResult _result = ZatcaQrDecoder.decode(widget.qrData);
  bool _saved = false;

  @override
  void initState() {
    super.initState();
    _saveValidScan();
  }

  Future<void> _saveValidScan() async {
    if (!_result.isValid) return;
    await ScanHistoryStore.add(
      ScanHistoryItem(
        qrData: widget.qrData,
        scannedAt: DateTime.now(),
        sellerName: _result.sellerName,
        invoiceTotal: _result.invoiceTotal,
        vatTotal: _result.vatTotal,
        isPhase2: _result.isPhase2,
      ),
    );
    if (mounted) setState(() => _saved = true);
  }

  String _tagName(int tag, AppLocalizations l10n) {
    switch (tag) {
      case 1:
        return l10n.tagSellerName;
      case 2:
        return l10n.tagVatNumber;
      case 3:
        return l10n.tagTimestamp;
      case 4:
        return l10n.tagInvoiceTotal;
      case 5:
        return l10n.tagVatTotal;
      case 6:
        return l10n.tagInvoiceHash;
      case 7:
        return l10n.tagEcdsaSig;
      case 8:
        return l10n.tagEcdsaPubKey;
      case 9:
        return l10n.tagZatcaStamp;
      default:
        return '${l10n.tagUnknown} ($tag)';
    }
  }

  String _buildShareText(AppLocalizations l10n) {
    final buffer = StringBuffer()
      ..writeln(l10n.appTitle)
      ..writeln(_result.isPhase2 ? l10n.phase2Text : l10n.phase1Text)
      ..writeln('');

    for (final entry in _result.tags.entries) {
      buffer.writeln('${_tagName(entry.key, l10n)}: ${entry.value}');
    }
    return buffer.toString().trim();
  }

  Future<void> _copyAll(AppLocalizations l10n) async {
    await Clipboard.setData(ClipboardData(text: _buildShareText(l10n)));
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(l10n.copiedMessage)));
  }

  Future<void> _share(AppLocalizations l10n) async {
    await Share.share(_buildShareText(l10n));
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;

    return WillPopScope(
      onWillPop: () async {
        Navigator.pop(context, _saved);
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(l10n.resultScreenTitle),
          actions: _result.isValid
              ? [
                  IconButton(
                    tooltip: l10n.copyAllBtn,
                    onPressed: () => _copyAll(l10n),
                    icon: const Icon(Icons.copy),
                  ),
                  IconButton(
                    tooltip: l10n.shareBtn,
                    onPressed: () => _share(l10n),
                    icon: const Icon(Icons.share),
                  ),
                ]
              : null,
        ),
        body: !_result.isValid
            ? _buildErrorView(context, l10n)
            : Column(
                children: [
                  _buildPhaseBanner(_result, l10n),
                  Expanded(
                    child: ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        _buildSummaryCard(context, l10n, _result),
                        const SizedBox(height: 8),
                        for (final tag in _result.tags.keys.toList()..sort())
                          _buildTagCard(_tagName(tag, l10n), _result.tags[tag]!),
                        const SizedBox(height: 16),
                        FilledButton.icon(
                          onPressed: () => Navigator.pop(context, _saved),
                          icon: const Icon(Icons.qr_code_scanner),
                          label: Text(l10n.scanAgainBtn),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  Widget _buildSummaryCard(BuildContext context, AppLocalizations l10n, ZatcaQrResult result) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _summaryLine(l10n.sellerLabel, result.sellerName),
            _summaryLine(l10n.totalLabel, result.invoiceTotal),
            _summaryLine(l10n.vatLabel, result.vatTotal),
            _summaryLine(l10n.dateLabel, result.timestamp),
          ],
        ),
      ),
    );
  }

  Widget _summaryLine(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(width: 90, child: Text(label, style: const TextStyle(fontWeight: FontWeight.bold))),
          Expanded(child: SelectableText(value.isEmpty ? '-' : value)),
        ],
      ),
    );
  }

  Widget _buildTagCard(String tagName, String value) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              tagName,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: Colors.blueGrey),
            ),
            const SizedBox(height: 8),
            SelectableText(value, style: const TextStyle(fontSize: 16)),
          ],
        ),
      ),
    );
  }

  Widget _buildPhaseBanner(ZatcaQrResult result, AppLocalizations l10n) {
    final isPhase2 = result.isPhase2;
    return Container(
      width: double.infinity,
      color: isPhase2 ? Colors.indigo.shade100 : Colors.green.shade100,
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(isPhase2 ? Icons.verified_user : Icons.receipt_long, color: isPhase2 ? Colors.indigo : Colors.green),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  isPhase2 ? l10n.phase2Text : l10n.phase1Text,
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: isPhase2 ? Colors.indigo : Colors.green.shade900),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(l10n.phaseDisclaimer, style: const TextStyle(fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildErrorView(BuildContext context, AppLocalizations l10n) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 64, color: Colors.redAccent),
            const SizedBox(height: 16),
            Text(l10n.invalidQrTitle, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            Text(l10n.invalidQrBody, textAlign: TextAlign.center, style: const TextStyle(color: Colors.black54)),
            const SizedBox(height: 24),
            FilledButton(onPressed: () => Navigator.pop(context, false), child: Text(l10n.goBackBtn)),
          ],
        ),
      ),
    );
  }
}

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  late Future<List<ScanHistoryItem>> _future = ScanHistoryStore.load();

  void _reload() => setState(() => _future = ScanHistoryStore.load());

  Future<void> _clearHistory(AppLocalizations l10n) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(l10n.clearHistoryTitle),
        content: Text(l10n.clearHistoryBody),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: Text(l10n.cancelBtn)),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: Text(l10n.confirmBtn)),
        ],
      ),
    );
    if (confirm != true) return;
    await ScanHistoryStore.clear();
    _reload();
  }

  @override
  Widget build(BuildContext context) {
    final l10n = AppLocalizations.of(context)!;
    return Scaffold(
      appBar: AppBar(
        title: Text(l10n.historyButton),
        actions: [
          IconButton(
            tooltip: l10n.clearHistoryButton,
            onPressed: () => _clearHistory(l10n),
            icon: const Icon(Icons.delete_sweep),
          ),
        ],
      ),
      body: FutureBuilder<List<ScanHistoryItem>>(
        future: _future,
        builder: (context, snapshot) {
          final items = snapshot.data ?? [];
          if (items.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.history, size: 64, color: Theme.of(context).colorScheme.outline),
                    const SizedBox(height: 16),
                    Text(l10n.noHistoryTitle, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 8),
                    Text(l10n.noHistoryBody, textAlign: TextAlign.center),
                  ],
                ),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            itemBuilder: (context, index) {
              final item = items[index];
              return Dismissible(
                key: ValueKey(item.qrData),
                background: Container(
                  alignment: Alignment.centerRight,
                  padding: const EdgeInsets.symmetric(horizontal: 24),
                  color: Colors.redAccent,
                  child: const Icon(Icons.delete, color: Colors.white),
                ),
                onDismissed: (_) async {
                  await ScanHistoryStore.remove(item.qrData);
                  _reload();
                },
                child: Card(
                  child: ListTile(
                    leading: Icon(item.isPhase2 ? Icons.verified_user : Icons.receipt_long),
                    title: Text(item.sellerName.isEmpty ? l10n.phaseUnknownText : item.sellerName, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text('${l10n.totalLabel}: ${item.invoiceTotal} • ${l10n.vatLabel}: ${item.vatTotal}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      await Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => ResultScreen(qrData: item.qrData)),
                      );
                      _reload();
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}


