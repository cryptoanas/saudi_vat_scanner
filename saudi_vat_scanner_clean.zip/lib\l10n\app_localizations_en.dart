// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get appTitle => 'Saudi VAT Invoice Reader';

  @override
  String get supportText =>
      'Reads Saudi e-invoice QR details in TLV Base64 format';

  @override
  String get scanButton => 'Scan QR Code';

  @override
  String get historyButton => 'Scan History';

  @override
  String get clearHistoryButton => 'Clear History';

  @override
  String get languageButton => 'العربية';

  @override
  String get scanScreenTitle => 'Scan E-Invoice QR';

  @override
  String get resultScreenTitle => 'Invoice Details';

  @override
  String get phase1Text => 'Phase 1 (Generation) Invoice';

  @override
  String get phase2Text => 'Phase 2 (Integration) Invoice';

  @override
  String get phaseUnknownText => 'Invoice QR details';

  @override
  String get phaseDisclaimer =>
      'This app reads QR data only. It does not verify invoice authenticity with ZATCA.';

  @override
  String get invalidQrTitle => 'Invalid ZATCA QR Code';

  @override
  String get invalidQrBody =>
      'The scanned code could not be parsed. Ensure you are scanning a valid Saudi e-invoice QR code encoded in TLV Base64 format.';

  @override
  String get goBackBtn => 'Go Back';

  @override
  String get scanAgainBtn => 'Scan Again';

  @override
  String get copyAllBtn => 'Copy All';

  @override
  String get shareBtn => 'Share';

  @override
  String get copiedMessage => 'Invoice details copied';

  @override
  String get noHistoryTitle => 'No scans yet';

  @override
  String get noHistoryBody =>
      'Scanned invoices will appear here on this device.';

  @override
  String get deleteBtn => 'Delete';

  @override
  String get clearHistoryTitle => 'Clear scan history?';

  @override
  String get clearHistoryBody =>
      'This will remove all saved scan results from this device.';

  @override
  String get cancelBtn => 'Cancel';

  @override
  String get confirmBtn => 'Clear';

  @override
  String get sampleNote => 'Use a real Saudi e-invoice QR code to test.';

  @override
  String get cameraPermissionNote =>
      'Camera access is required to scan invoice QR codes.';

  @override
  String get sellerLabel => 'Seller';

  @override
  String get totalLabel => 'Total';

  @override
  String get vatLabel => 'VAT';

  @override
  String get dateLabel => 'Date';

  @override
  String get tagSellerName => 'Seller Name';

  @override
  String get tagVatNumber => 'VAT Registration Number';

  @override
  String get tagTimestamp => 'Timestamp';

  @override
  String get tagInvoiceTotal => 'Invoice Total (with VAT)';

  @override
  String get tagVatTotal => 'VAT Total';

  @override
  String get tagInvoiceHash => 'Invoice Hash (Phase 2)';

  @override
  String get tagEcdsaSig => 'ECDSA Signature (Phase 2)';

  @override
  String get tagEcdsaPubKey => 'ECDSA Public Key (Phase 2)';

  @override
  String get tagZatcaStamp => 'ZATCA Stamp Signature (Phase 2)';

  @override
  String get tagUnknown => 'Unknown Tag';
}
