# Release Checklist

## Before Play Store release

- Replace AdMob test app ID and test banner unit IDs with real IDs.
- Add Android package name, app icon, and app label.
- Add camera permission in AndroidManifest.xml.
- Add privacy policy URL in Play Console.
- Test camera scanning on at least 3 Android devices.
- Test Arabic and English screens.
- Test invalid QR codes.
- Test real Saudi invoice QR codes from Phase 1 and Phase 2 invoices.
- Confirm app description does not say official ZATCA verification.

## Recommended Play Store wording

Title:
Saudi VAT Invoice Reader

Short description:
Read Saudi e-invoice QR details in Arabic and English.

Disclaimer:
This app reads QR data only and does not verify invoice authenticity with ZATCA.
