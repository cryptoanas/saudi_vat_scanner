import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:intl/intl.dart' as intl;

import 'app_localizations_ar.dart';
import 'app_localizations_en.dart';

// ignore_for_file: type=lint

/// Callers can lookup localized strings with an instance of AppLocalizations
/// returned by `AppLocalizations.of(context)`.
///
/// Applications need to include `AppLocalizations.delegate()` in their app's
/// `localizationDelegates` list, and the locales they support in the app's
/// `supportedLocales` list. For example:
///
/// ```dart
/// import 'l10n/app_localizations.dart';
///
/// return MaterialApp(
///   localizationsDelegates: AppLocalizations.localizationsDelegates,
///   supportedLocales: AppLocalizations.supportedLocales,
///   home: MyApplicationHome(),
/// );
/// ```
///
/// ## Update pubspec.yaml
///
/// Please make sure to update your pubspec.yaml to include the following
/// packages:
///
/// ```yaml
/// dependencies:
///   # Internationalization support.
///   flutter_localizations:
///     sdk: flutter
///   intl: any # Use the pinned version from flutter_localizations
///
///   # Rest of dependencies
/// ```
///
/// ## iOS Applications
///
/// iOS applications define key application metadata, including supported
/// locales, in an Info.plist file that is built into the application bundle.
/// To configure the locales supported by your app, you’ll need to edit this
/// file.
///
/// First, open your project’s ios/Runner.xcworkspace Xcode workspace file.
/// Then, in the Project Navigator, open the Info.plist file under the Runner
/// project’s Runner folder.
///
/// Next, select the Information Property List item, select Add Item from the
/// Editor menu, then select Localizations from the pop-up menu.
///
/// Select and expand the newly-created Localizations item then, for each
/// locale your application supports, add a new item and select the locale
/// you wish to add from the pop-up menu in the Value field. This list should
/// be consistent with the languages listed in the AppLocalizations.supportedLocales
/// property.
abstract class AppLocalizations {
  AppLocalizations(String locale)
      : localeName = intl.Intl.canonicalizedLocale(locale.toString());

  final String localeName;

  static AppLocalizations? of(BuildContext context) {
    return Localizations.of<AppLocalizations>(context, AppLocalizations);
  }

  static const LocalizationsDelegate<AppLocalizations> delegate =
      _AppLocalizationsDelegate();

  /// A list of this localizations delegate along with the default localizations
  /// delegates.
  ///
  /// Returns a list of localizations delegates containing this delegate along with
  /// GlobalMaterialLocalizations.delegate, GlobalCupertinoLocalizations.delegate,
  /// and GlobalWidgetsLocalizations.delegate.
  ///
  /// Additional delegates can be added by appending to this list in
  /// MaterialApp. This list does not have to be used at all if a custom list
  /// of delegates is preferred or required.
  static const List<LocalizationsDelegate<dynamic>> localizationsDelegates =
      <LocalizationsDelegate<dynamic>>[
    delegate,
    GlobalMaterialLocalizations.delegate,
    GlobalCupertinoLocalizations.delegate,
    GlobalWidgetsLocalizations.delegate,
  ];

  /// A list of this localizations delegate's supported locales.
  static const List<Locale> supportedLocales = <Locale>[
    Locale('ar'),
    Locale('en')
  ];

  /// No description provided for @appTitle.
  ///
  /// In en, this message translates to:
  /// **'Saudi VAT Invoice Reader'**
  String get appTitle;

  /// No description provided for @supportText.
  ///
  /// In en, this message translates to:
  /// **'Reads Saudi e-invoice QR details in TLV Base64 format'**
  String get supportText;

  /// No description provided for @scanButton.
  ///
  /// In en, this message translates to:
  /// **'Scan QR Code'**
  String get scanButton;

  /// No description provided for @historyButton.
  ///
  /// In en, this message translates to:
  /// **'Scan History'**
  String get historyButton;

  /// No description provided for @clearHistoryButton.
  ///
  /// In en, this message translates to:
  /// **'Clear History'**
  String get clearHistoryButton;

  /// No description provided for @languageButton.
  ///
  /// In en, this message translates to:
  /// **'العربية'**
  String get languageButton;

  /// No description provided for @scanScreenTitle.
  ///
  /// In en, this message translates to:
  /// **'Scan E-Invoice QR'**
  String get scanScreenTitle;

  /// No description provided for @resultScreenTitle.
  ///
  /// In en, this message translates to:
  /// **'Invoice Details'**
  String get resultScreenTitle;

  /// No description provided for @phase1Text.
  ///
  /// In en, this message translates to:
  /// **'Phase 1 (Generation) Invoice'**
  String get phase1Text;

  /// No description provided for @phase2Text.
  ///
  /// In en, this message translates to:
  /// **'Phase 2 (Integration) Invoice'**
  String get phase2Text;

  /// No description provided for @phaseUnknownText.
  ///
  /// In en, this message translates to:
  /// **'Invoice QR details'**
  String get phaseUnknownText;

  /// No description provided for @phaseDisclaimer.
  ///
  /// In en, this message translates to:
  /// **'This app reads QR data only. It does not verify invoice authenticity with ZATCA.'**
  String get phaseDisclaimer;

  /// No description provided for @invalidQrTitle.
  ///
  /// In en, this message translates to:
  /// **'Invalid ZATCA QR Code'**
  String get invalidQrTitle;

  /// No description provided for @invalidQrBody.
  ///
  /// In en, this message translates to:
  /// **'The scanned code could not be parsed. Ensure you are scanning a valid Saudi e-invoice QR code encoded in TLV Base64 format.'**
  String get invalidQrBody;

  /// No description provided for @goBackBtn.
  ///
  /// In en, this message translates to:
  /// **'Go Back'**
  String get goBackBtn;

  /// No description provided for @scanAgainBtn.
  ///
  /// In en, this message translates to:
  /// **'Scan Again'**
  String get scanAgainBtn;

  /// No description provided for @copyAllBtn.
  ///
  /// In en, this message translates to:
  /// **'Copy All'**
  String get copyAllBtn;

  /// No description provided for @shareBtn.
  ///
  /// In en, this message translates to:
  /// **'Share'**
  String get shareBtn;

  /// No description provided for @copiedMessage.
  ///
  /// In en, this message translates to:
  /// **'Invoice details copied'**
  String get copiedMessage;

  /// No description provided for @noHistoryTitle.
  ///
  /// In en, this message translates to:
  /// **'No scans yet'**
  String get noHistoryTitle;

  /// No description provided for @noHistoryBody.
  ///
  /// In en, this message translates to:
  /// **'Scanned invoices will appear here on this device.'**
  String get noHistoryBody;

  /// No description provided for @deleteBtn.
  ///
  /// In en, this message translates to:
  /// **'Delete'**
  String get deleteBtn;

  /// No description provided for @clearHistoryTitle.
  ///
  /// In en, this message translates to:
  /// **'Clear scan history?'**
  String get clearHistoryTitle;

  /// No description provided for @clearHistoryBody.
  ///
  /// In en, this message translates to:
  /// **'This will remove all saved scan results from this device.'**
  String get clearHistoryBody;

  /// No description provided for @cancelBtn.
  ///
  /// In en, this message translates to:
  /// **'Cancel'**
  String get cancelBtn;

  /// No description provided for @confirmBtn.
  ///
  /// In en, this message translates to:
  /// **'Clear'**
  String get confirmBtn;

  /// No description provided for @sampleNote.
  ///
  /// In en, this message translates to:
  /// **'Use a real Saudi e-invoice QR code to test.'**
  String get sampleNote;

  /// No description provided for @cameraPermissionNote.
  ///
  /// In en, this message translates to:
  /// **'Camera access is required to scan invoice QR codes.'**
  String get cameraPermissionNote;

  /// No description provided for @sellerLabel.
  ///
  /// In en, this message translates to:
  /// **'Seller'**
  String get sellerLabel;

  /// No description provided for @totalLabel.
  ///
  /// In en, this message translates to:
  /// **'Total'**
  String get totalLabel;

  /// No description provided for @vatLabel.
  ///
  /// In en, this message translates to:
  /// **'VAT'**
  String get vatLabel;

  /// No description provided for @dateLabel.
  ///
  /// In en, this message translates to:
  /// **'Date'**
  String get dateLabel;

  /// No description provided for @tagSellerName.
  ///
  /// In en, this message translates to:
  /// **'Seller Name'**
  String get tagSellerName;

  /// No description provided for @tagVatNumber.
  ///
  /// In en, this message translates to:
  /// **'VAT Registration Number'**
  String get tagVatNumber;

  /// No description provided for @tagTimestamp.
  ///
  /// In en, this message translates to:
  /// **'Timestamp'**
  String get tagTimestamp;

  /// No description provided for @tagInvoiceTotal.
  ///
  /// In en, this message translates to:
  /// **'Invoice Total (with VAT)'**
  String get tagInvoiceTotal;

  /// No description provided for @tagVatTotal.
  ///
  /// In en, this message translates to:
  /// **'VAT Total'**
  String get tagVatTotal;

  /// No description provided for @tagInvoiceHash.
  ///
  /// In en, this message translates to:
  /// **'Invoice Hash (Phase 2)'**
  String get tagInvoiceHash;

  /// No description provided for @tagEcdsaSig.
  ///
  /// In en, this message translates to:
  /// **'ECDSA Signature (Phase 2)'**
  String get tagEcdsaSig;

  /// No description provided for @tagEcdsaPubKey.
  ///
  /// In en, this message translates to:
  /// **'ECDSA Public Key (Phase 2)'**
  String get tagEcdsaPubKey;

  /// No description provided for @tagZatcaStamp.
  ///
  /// In en, this message translates to:
  /// **'ZATCA Stamp Signature (Phase 2)'**
  String get tagZatcaStamp;

  /// No description provided for @tagUnknown.
  ///
  /// In en, this message translates to:
  /// **'Unknown Tag'**
  String get tagUnknown;
}

class _AppLocalizationsDelegate
    extends LocalizationsDelegate<AppLocalizations> {
  const _AppLocalizationsDelegate();

  @override
  Future<AppLocalizations> load(Locale locale) {
    return SynchronousFuture<AppLocalizations>(lookupAppLocalizations(locale));
  }

  @override
  bool isSupported(Locale locale) =>
      <String>['ar', 'en'].contains(locale.languageCode);

  @override
  bool shouldReload(_AppLocalizationsDelegate old) => false;
}

AppLocalizations lookupAppLocalizations(Locale locale) {
  // Lookup logic when only language code is specified.
  switch (locale.languageCode) {
    case 'ar':
      return AppLocalizationsAr();
    case 'en':
      return AppLocalizationsEn();
  }

  throw FlutterError(
      'AppLocalizations.delegate failed to load unsupported locale "$locale". This is likely '
      'an issue with the localizations generation tool. Please file an issue '
      'on GitHub with a reproducible sample app and the gen-l10n configuration '
      'that was used.');
}
