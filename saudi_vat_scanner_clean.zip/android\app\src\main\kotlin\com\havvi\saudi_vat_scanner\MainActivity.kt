package com.havvi.saudi_vat_scanner

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
