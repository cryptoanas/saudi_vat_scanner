// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Arabic (`ar`).
class AppLocalizationsAr extends AppLocalizations {
  AppLocalizationsAr([String locale = 'ar']) : super(locale);

  @override
  String get appTitle => 'قارئ الفاتورة الضريبية السعودية';

  @override
  String get supportText =>
      'قراءة تفاصيل رمز QR للفواتير الإلكترونية السعودية بصيغة TLV Base64';

  @override
  String get scanButton => 'مسح رمز QR';

  @override
  String get historyButton => 'سجل المسح';

  @override
  String get clearHistoryButton => 'مسح السجل';

  @override
  String get languageButton => 'English';

  @override
  String get scanScreenTitle => 'مسح رمز الفاتورة الإلكترونية';

  @override
  String get resultScreenTitle => 'تفاصيل الفاتورة';

  @override
  String get phase1Text => 'فاتورة المرحلة الأولى (الإصدار)';

  @override
  String get phase2Text => 'فاتورة المرحلة الثانية (الربط والتكامل)';

  @override
  String get phaseUnknownText => 'تفاصيل رمز الفاتورة';

  @override
  String get phaseDisclaimer =>
      'يقوم التطبيق بقراءة بيانات QR فقط، ولا يتحقق من صحة الفاتورة عبر هيئة الزكاة والضريبة والجمارك.';

  @override
  String get invalidQrTitle => 'رمز QR غير صالح';

  @override
  String get invalidQrBody =>
      'تعذر تحليل الرمز الممسوح ضوئيًا. تأكد من مسح رمز QR صحيح لفاتورة إلكترونية سعودية بصيغة TLV Base64.';

  @override
  String get goBackBtn => 'رجوع';

  @override
  String get scanAgainBtn => 'مسح مرة أخرى';

  @override
  String get copyAllBtn => 'نسخ الكل';

  @override
  String get shareBtn => 'مشاركة';

  @override
  String get copiedMessage => 'تم نسخ تفاصيل الفاتورة';

  @override
  String get noHistoryTitle => 'لا يوجد سجل حتى الآن';

  @override
  String get noHistoryBody =>
      'ستظهر الفواتير التي تم مسحها هنا على هذا الجهاز.';

  @override
  String get deleteBtn => 'حذف';

  @override
  String get clearHistoryTitle => 'مسح سجل المسح؟';

  @override
  String get clearHistoryBody =>
      'سيتم حذف جميع نتائج المسح المحفوظة من هذا الجهاز.';

  @override
  String get cancelBtn => 'إلغاء';

  @override
  String get confirmBtn => 'مسح';

  @override
  String get sampleNote =>
      'استخدم رمز QR حقيقي لفاتورة إلكترونية سعودية للتجربة.';

  @override
  String get cameraPermissionNote =>
      'يلزم السماح باستخدام الكاميرا لمسح رموز الفواتير.';

  @override
  String get sellerLabel => 'البائع';

  @override
  String get totalLabel => 'الإجمالي';

  @override
  String get vatLabel => 'الضريبة';

  @override
  String get dateLabel => 'التاريخ';

  @override
  String get tagSellerName => 'اسم البائع';

  @override
  String get tagVatNumber => 'رقم التسجيل الضريبي';

  @override
  String get tagTimestamp => 'الوقت والتاريخ';

  @override
  String get tagInvoiceTotal => 'إجمالي الفاتورة شامل الضريبة';

  @override
  String get tagVatTotal => 'إجمالي ضريبة القيمة المضافة';

  @override
  String get tagInvoiceHash => 'تشفير الفاتورة (المرحلة الثانية)';

  @override
  String get tagEcdsaSig => 'توقيع ECDSA (المرحلة الثانية)';

  @override
  String get tagEcdsaPubKey => 'المفتاح العام ECDSA (المرحلة الثانية)';

  @override
  String get tagZatcaStamp =>
      'ختم هيئة الزكاة والضريبة والجمارك (المرحلة الثانية)';

  @override
  String get tagUnknown => 'علامة غير معروفة';
}
